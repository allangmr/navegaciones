/**
 * @author pdhindsa
 */
$.paramquery.pqGrid.regional['pt'] = {
    strAdd: "Adicionar",
    strDelete: "Excluir",        
    strEdit: "Editar",
    strLoading: "Carregamento",
    strNextResult: "Próximo resultado",        
    strNoRows: "Não há linhas para mostrar.",        
    strNothingFound: "Nada foi encontrado",
    strPrevResult: "Resultado anterior",
    strSearch: "Pesquisar",
    strSelectedmatches: "Selecionado {0} de {1} match (es)"    
};
$.paramquery.pqPager.regional['pt'] = {
    strDisplay:"Exibindo {0} para {1} de {2} itens.",		
    strFirstPage:"Primeira Página",
    strLastPage:"Última Página",
    strNextPage:"Página Seguinte",        
    strPage:"Página {0} de {1}",
    strPrevPage:"Página Anterior",	
    strRefresh:"Refrescar",	
    strRpp:"Registros por página: {0}"	
};
