/*
 * @author Brkhn
 */
$.paramquery.pqGrid.regional['tr'] = { 
    strLoading: "Yükleniyor",
    strNoRows: "Gösterilecek Satır Yok.",
    strAdd: "Ekle",
    strEdit: "Düzenle",
    strDelete: "Sil",
    strSearch: "Ara",
    strNothingFound: "Sonuç Bunulamadı",
    strSelectedmatches: "{0} seçilen arasında {1} eşleşen",
    strPrevResult: "Önceki Kayıt",
    strNextResult: "Sonraki Kayıt"    
}; 
$.paramquery.pqPager.regional['tr'] = { 
    strPage: "{1} Sayfadan {0} gösteriliyor",
    strFirstPage: "İlk Sayfa",
    strPrevPage: "Önceki Sayfa",
    strNextPage: "Sonraki Sayfa",
    strLastPage: "Son Sayfa",
    strRefresh: "Yenile",
    strRpp: "Gösterilecek Kayıt: {0}",
    strDisplay: "{2} Kayıttan {0} ile {1} arası görüntüleniyor."
};